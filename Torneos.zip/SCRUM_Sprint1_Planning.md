# Sprint 1 - Planning (PWA Torneos)

**Fecha de inicio:** 2025-11-15  
**Duración:** 2 semanas (Sprint 1)  
**Objetivo del Sprint:** Implementar el flujo de inscripción de atletas, gestión básica de torneos y registro de tiempos manual.

## Historias seleccionadas (Prioridad alta)
1. **US-01** - Registro e inicio de sesión de usuarios (PO: validar).  
   - Criterios de aceptación: Registro vía email, login con JWT, rol admin/organizador.
2. **US-02** - Crear/Editar/Eliminar Torneos (Admin).  
3. **US-03** - Inscripción de atletas a torneos (público).  
4. **US-04** - Registro manual de tiempos por organizador.  
5. **US-05** - Visualización de resultados y clasificaciones.

## Tareas (por historia) y estimaciones (Story Points)
- US-01
  - T1: Endpoint register/login - 3 SP - Dev: Ana
  - T2: Frontend forms register/login - 2 SP - Dev: Luis
  - T3: Tests básicos auth - 1 SP - Dev: Ana

- US-02
  - T4: Endpoints CRUD torneos - 3 SP - Dev: Maria
  - T5: Frontend CRUD UI - 3 SP - Dev: Luis
  - T6: Tests - 1 SP - Dev: Maria

- US-03
  - T7: Endpoint inscripción - 2 SP - Dev: Maria
  - T8: Frontend inscripción - 2 SP - Dev: Luis

- US-04
  - T9: Endpoint registro tiempos - 2 SP - Dev: Ana
  - T10: UI registro tiempos - 2 SP - Dev: Luis

- US-05
  - T11: Endpoint resultados - 2 SP - Dev: Maria
  - T12: UI resultados y clasificación - 3 SP - Dev: Luis

## Definition of Done
- Código con pruebas unitarias básicas.
- Documentación de endpoints en OpenAPI.
- Deploy local reproducible con script.
- Aprobación PO en demo.

## Riesgos y Mitigaciones
- Integraciones externas -> pruebas con stubs.
- Datos reales de competición -> usar dataset de muestra (included CSV).

