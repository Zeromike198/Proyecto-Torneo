# Manual Técnico Completo - PWA Torneos

## Resumen
Documento complementario con instalación, DoD, estructura del proyecto y cómo probar endpoints.

## Instalación (local)
1. Clonar el repositorio.
2. Backend:
   - cd backend
   - npm install
   - cp .env.example .env (configurar variables: DB, JWT_SECRET)
   - npm run dev (por defecto en http://localhost:3000)
3. Frontend:
   - cd frontend
   - npm install
   - npm run dev (por defecto http://localhost:5173)

## Endpoints (resumen)
- /auth/login - POST
- /auth/register - POST
- /tournaments - GET, POST
- /tournaments/{id} - GET, PUT, DELETE
- /tournaments/{tournamentId}/events - GET, POST
- /athletes - GET, POST
- /inscriptions - GET, POST
- /results - GET, POST

## Definición de Done (DoD)
- Código documentado y con README.
- Tests unitarios básicos (donde aplicable).
- Endpoints críticos con pruebas manuales.
- OpenAPI actualizado en /openapi_complete.yaml

## Notas adicionales
- Para pruebas rápidas puede usarse Postman o Swagger UI apuntando a openapi_complete.yaml.

---

## Instalación y entorno (paso a paso)

### Requisitos
- Node.js >= 18
- npm o yarn
- MySQL 8
- Git

### Variables de entorno (archivo .env)
```
PORT=4000
DB_HOST=localhost
DB_USER=root
DB_PASS=changeme
DB_NAME=pwa_torneos
JWT_SECRET=your_jwt_secret
```

### Scripts útiles
- `cd backend && npm install && npm run dev` - Inicia backend
- `cd frontend && npm install && npm run dev` - Inicia frontend
- `mysql -u root -p pwa_torneos < sql_migration.sql` - Crea tablas

## Diagramas de flujo (Resumen)
1. Registro/Login -> obtiene JWT -> accede a rutas protegidas.
2. Creación de torneo -> registro en tabla tournaments.
3. Inscripción -> crea fila en inscriptions.
4. Registro tiempos -> inserta en results y actualiza clasificación.

## Checklist de entrega (para validar 20/20)
- [x] Archivo Figma editable incluido.
- [x] OpenAPI documentado (openapi_complete.yaml).
- [x] Diagrama BD editable (db_diagram.drawio) y SQL migration.
- [x] Sprint planning y Trello export.
- [x] Manual técnico con instalación.
- [x] Endpoints básicos implementados en backend (auth, tournaments, athletes, inscriptions, results).
- [x] README con comandos para correr localmente.

