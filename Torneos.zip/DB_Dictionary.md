# Diccionario de Datos - PWA Torneos

## Tables
- users (id PK, email, password_hash, role)
- tournaments (id PK, name, date, location, category)
- athletes (id PK, name, dob, gender, country)
- inscriptions (id PK, tournament_id FK->tournaments.id, athlete_id FK->athletes.id, category, status)
- results (id PK, inscription_id FK->inscriptions.id, time_seconds, recorded_by, recorded_at)
- audit_logs (id PK, table_name, record_id, action, user_id, timestamp)

