USE pwa_torneos;
INSERT INTO users (name,email,password_hash,role) VALUES ('Admin','admin@example.com','$2b$10$Ff1q2y5fQJqGz4wY8gqW/Od2r6YfX3YJvAqzKfQzK8p6hG1Zb8Gm','admin');