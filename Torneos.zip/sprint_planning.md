# Sprint Planning - Sprint 1
Objetivo: Autenticación, BD inicial, dashboard básico.

Tareas:
- Configurar repositorios (1)
- Setup React+Vite (1)
- Setup Express (1)
- Modelo BD MySQL (2)
- Endpoints auth (3)
- UI login/dashboard (3)
- Pruebas integración (2)
