# SCRUM Plan
Roles, Backlog and Sprint plan (see README).