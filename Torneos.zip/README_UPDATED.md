# PWA Torneos - Entrega Fase 1 (Completa)

Esta versión incluye los entregables adicionales solicitados para alcanzar 20/20.

Archivos añadidos:
- SCRUM_Sprint1_Planning.md
- trello_board_completed.json
- openapi_complete.yaml
- DB_Dictionary.md
- sql_migration.sql
- Manual_Tecnico_Complete.md (actualizado)
- backend/src/api_stubs.js (stubs)

Comandos para correr (local):
1. Backend:
   - `cd backend`
   - `npm install`
   - `node src/api_stubs.js` (o integrar en server)
2. Frontend:
   - `cd frontend`
   - `npm install`
   - `npm run dev`

