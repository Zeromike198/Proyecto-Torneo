Entrega Final Completa - PWA Torneos (Fase 1)
Alumno: Richard Quintero - Cédula: 30380344

Pasos: Import SQL, start backend (node), start frontend (vite)
Credenciales demo: amind@uvm.edu / admin123
