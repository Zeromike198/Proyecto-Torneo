# Sprint 1 - Planning (Detalle de tareas)

**Duración:** 2 semanas  
**Objetivo:** Establecer cimientos (auth, modelo atleta, inscripciones, dashboard, OpenAPI)

## Tareas (desglosadas)
- T1: Configurar repositorio y scripts (install, dev, build) - Dev - 1d
- T2: Configurar base de datos y seed (MySQL) - Dev - 2d
- T3: Implementar Auth (register/login + JWT) - Dev - 3d
- T4: Crear endpoints atletas (CRUD) - Dev - 3d
- T5: Implementar inscripciones - Dev - 3d
- T6: Crear dashboard básico - Dev - 3d
- T7: Generar OpenAPI para auth y atletas - Dev - 1d
- T8: Documentación (README + Manual técnico) - Dev - 2d
- T9: Preparar video demo - PO/Dev - 1d

## Criterios de aceptación (ejemplo)
- Login y Register funcionan con tokens y guardan en la BD.
- CRUD de atletas pasa pruebas manuales (crear, listar).
- Endpoint de inscripciones guarda relación atleta-evento.
- OpenAPI valida con Swagger Editor.

## Sprint backlog (prioridad)
1. Auth  
2. Modelo Atleta  
3. Inscripciones  
4. OpenAPI  
5. Dashboard  
6. Documentación  
7. Video
