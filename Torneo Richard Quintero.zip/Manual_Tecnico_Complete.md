# Manual Técnico - PWA Torneos (Versión Avance 1)

## Resumen
Este manual describe la instalación, estructura y funcionamiento básico del proyecto PWA Torneos.

## Requisitos
- Node.js >= 18
- npm >= 9
- MySQL 8 (o compatible)
- Git (opcional)

## Estructura del repositorio (resumen)
- /frontend - React + Vite app
- /backend - Node.js + Express API
- /design - Figma / wireframes
- /docs - Documentación adicional
- openapi_complete.yaml - Especificación OpenAPI

## Instalación local (pasos)
1. Clonar repositorio.
2. Backend:
   - `cd backend`
   - Copiar `.env.example` a `.env` y configurar variables (DB_HOST, DB_USER, DB_PASS, DB_NAME, JWT_SECRET)
   - `npm install`
   - Crear DB y correr script: `mysql -u user -p < pwa_torneos_schema.sql`
   - (Opcional) `node backend/src/index.js` para correr el servidor.
3. Frontend:
   - `cd frontend`
   - `npm install`
   - `npm run dev` (o `npm run build` + `npm run preview` para revisar PWA en producción)
4. Acceder a `http://localhost:5173` (o puerto que indique Vite).

## PWA: Manifest y Service Worker
- El proyecto incluye un `manifest.json` en `/public/manifest.json` y un `sw.js` en `/public/sw.js`.
- Para probar PWA en local:
  1. Ejecutar `npm run build` en frontend.
  2. Ejecutar `npx serve dist` o `npm run preview` (Vite) para servir `dist` sobre http(s).
  3. Abrir Chrome DevTools → Lighthouse para auditar PWA.

## Endpoints principales (resumen)
- `POST /api/auth/register` - Registrar usuario
- `POST /api/auth/login` - Login (retorna JWT)
- `GET /api/athletes` - Listar atletas
- `POST /api/athletes` - Crear atleta
- `POST /api/inscriptions` - Inscribir atleta a evento
- `GET /api/results` - Obtener resultados por evento

(Ver `openapi_complete.yaml` para la especificación completa)

## Diagrama de flujo (Login → Dashboard)
1. Usuario ingresa credenciales.
2. Frontend solicita token al backend (`/api/auth/login`).
3. Backend valida y retorna JWT.
4. Frontend guarda token (localStorage o cookie).
5. Usuario accede al dashboard y ejecuta peticiones autenticadas.

## Notas sobre seguridad
- En producción, usar cookies `httpOnly` o un nivel de protección mejor para el token.
- Validar inputs en server-side y client-side.
- No subir `.env` con credenciales reales.

## Cómo entregar (recomendado)
- Incluir en ZIP:
  - `VIDEO.txt` con enlace de YouTube.
  - PDF del SCRUM (opcional).
  - Capturas del Trello/Jira.
  - README profesional (se incluye).

---  
*Fin del Manual Técnico mejorado.*
