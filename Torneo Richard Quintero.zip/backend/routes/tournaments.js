const express = require('express');
const router = express.Router();
// GET /tournaments
router.get('/', (req, res) => res.json([]));
// POST /tournaments
router.post('/', (req, res) => res.status(201).json({}));
module.exports = router;