import React, { useState } from "react";
import axios from "axios";

export default function Login() {
    const [email, setEmail] = useState("admin@uvm.edu");
    const [password, setPassword] = useState("admin123");

    const submit = async (e) => {
        e.preventDefault();

        // Login FALSO — solo muestra mensaje
        const name = "Richard";

        alert("Inicio de sesión exitoso.\nBienvenido " + name + "!");
    };

    return (
        <div className="card" style={{ maxWidth: 420 }}>
            <h2>Iniciar sesión</h2>

            <form onSubmit={submit}>
                <div style={{ marginBottom: 8 }}>
                    <label>Email</label>
                    <br />
                    <input
                        style={{ width: "100%", padding: 8, borderRadius: 6 }}
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                    />
                </div>

                <div style={{ marginBottom: 8 }}>
                    <label>Contraseña</label>
                    <br />
                    <input
                        type="password"
                        style={{ width: "100%", padding: 8, borderRadius: 6 }}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                    />
                </div>

                <div style={{ display: "flex", gap: 8 }}>
                    <button className="button" type="submit">
                        Entrar
                    </button>
                </div>
            </form>
        </div>
    );
}