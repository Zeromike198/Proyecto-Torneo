PWA Torneos - Avance 1 (Mejorado)

Contenido del ZIP:
- frontend/ : Aplicación React + Vite
- backend/ : API en Node/Express
- design/ : Figma y wireframes
- openapi_complete.yaml : Especificación OpenAPI
- SCRUM_PLAN.md, backlog.csv, sprint_planning.md : Documentación SCRUM
- Manual_Tecnico_Complete.md : Manual técnico mejorado
- public/manifest.json, public/sw.js : Archivos PWA
- VIDEO.txt : Pegar el enlace de YouTube del demo

Instrucciones rápidas:
1. Backend: cd backend && npm install && configurar .env && npm run dev (o node src/index.js)
2. Frontend: cd frontend && npm install && npm run dev
3. Para probar PWA: cd frontend && npm run build && npm run preview

Si necesitas el PDF del SCRUM o que genere otros formatos, indica y lo agrego.

Contacto: Richard Quintero
