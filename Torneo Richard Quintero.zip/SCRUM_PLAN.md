# SCRUM Plan - PWA Torneos (Avance 1)  
**Proyecto:** PWA Torneos - Gestión de competiciones acuáticas y atletismo  
**Autor:** Richard Quintero  
**Fecha de entrega (Avance 1):** [Indicar fecha]  

---

## 1. Visión del producto
Crear una PWA que permita la inscripción de atletas, el registro de tiempos y la visualización de resultados para disciplinas: aguas abiertas, natación, acuatlón, triatlón y atletismo. Debe ser ágil, offline-capable y fácil de administrar desde un dashboard.

## 2. Equipo y Roles
- **Product Owner (PO):** Richard Quintero  
- **Scrum Master (SM):** Richard Quintero  
- **Developers:** Richard Quintero (Frontend / Backend)  
- **QA / Tester:** (Asignar si aplica)

> Nota: Si se trabaja en equipo, reemplazar nombres por los reales y agregar contactos.

## 3. Alcance del Avance 1 (50%)
- Documentación SCRUM inicial (backlog, roles, sprint planning)
- Wireframes y diseño UI/UX (Figma)
- Diagrama de base de datos (MySQL)
- Configuración inicial (React + Vite + Express)
- Autenticación básica y dashboard administrativo
- OpenAPI (especificaciones de endpoints)
- Manual técnico inicial y tutorial de instalación
- Video de demo (link incluido)

## 4. Definición de "Done" (Listo)
Un ítem del backlog se marca como "Done" si:
- Código mergeado en la rama principal.
- Tests (unitarios o manuales) ejecutados y documentados.
- Documentación actualizada (README / Manual técnico).
- Si aplica: deploy de preview (vite preview / deploy staging).

## 5. Product Backlog (resumen)
Ver `backlog.csv` para el backlog completo. Prioridad descendente (P0 = más alto).

## 6. Sprint 1 - Objetivos
- Configurar proyecto base (frontend + backend).
- Implementar autenticación (login/register + JWT).
- Crear modelo de atleta y endpoint de inscripción.
- Diseño de la pantalla de inicio y dashboard básico.
- Generar OpenAPI mínimo para auth y atletas.
- Preparar seed y script de creación de BD.

## 7. Riesgos y Mitigaciones
- **Riesgo:** Dependencias incompatibles (ej. CKEditor en otros proyectos).  
  **Mitigación:** Usar `--legacy-peer-deps` y pruebas de instalación limpia.
- **Riesgo:** Falta de tiempo para cubrir toda la lógica de eventos.  
  **Mitigación:** Priorizar lo crítico y dejar historias de menor prioridad para siguientes sprints.

## 8. Evidencias del tablero
Adjuntar capturas del tablero Trello/Jira (ya incluidas en el ZIP: `doc_screenshot_1.png`, `doc_screenshot_2.png`).

## 9. Contacto y enlaces
- Repositorio: (incluir enlace si aplica)  
- Video demo: ver archivo `VIDEO.txt` dentro del ZIP (pegar link de YouTube).

---  
*Este documento es la versión mejorada del SCRUM_PLAN.md original. Si deseas, puedo generar un PDF listo para imprimir.*  
